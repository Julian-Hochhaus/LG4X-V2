
You can unzip presets.zip file and choose the preset by "load" or "add" in preset menu. The preset files are based on the stadard binding energy table. Amplitude has to be optimized upon your intensity scale.
